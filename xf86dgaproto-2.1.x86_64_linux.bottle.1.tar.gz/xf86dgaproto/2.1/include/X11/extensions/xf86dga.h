#ifdef _XF86DGA_SERVER_

#warning "xf86dga.h is obsolete and may be removed in the future."
#warning "include <X11/extensions/xf86dgaconst.h> instead."
#include <X11/extensions/xf86dgaconst.h>

#else

#warning "xf86dga.h is obsolete and may be removed in the future."
#warning "include <X11/extensions/Xxf86dga.h> instead."
#include <X11/extensions/Xxf86dga.h>

#endif
