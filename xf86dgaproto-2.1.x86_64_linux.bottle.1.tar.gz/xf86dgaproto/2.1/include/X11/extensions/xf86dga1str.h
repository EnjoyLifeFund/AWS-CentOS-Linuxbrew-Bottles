#warning "xf86dga1str.h is obsolete and may be removed in the future."
#warning "include <X11/extensions/xf86dga1proto.h> for the protocol defines."
#include <X11/extensions/xf86dga1proto.h>
