+{
   locale_version => 1.19,
   entry => <<'ENTRY', # for DUCET v8.0.0
0149      ; [.1D34.0020.0009] # LATIN SMALL LETTER N PRECEDED BY APOSTROPHE
ENTRY
};
