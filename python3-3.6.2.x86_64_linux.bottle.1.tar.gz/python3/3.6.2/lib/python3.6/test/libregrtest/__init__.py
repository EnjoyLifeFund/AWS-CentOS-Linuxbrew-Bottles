# We import importlib *ASAP* in order to test #15386
import importlib

from test.libregrtest.cmdline import _parse_args, RESOURCE_NAMES
from test.libregrtest.main import main
