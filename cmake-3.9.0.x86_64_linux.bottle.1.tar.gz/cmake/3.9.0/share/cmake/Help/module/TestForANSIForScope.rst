.. cmake-module:: ../../Modules/TestForANSIForScope.cmake
