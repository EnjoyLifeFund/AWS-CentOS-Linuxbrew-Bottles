The Readme for analog can be found in the file docs/Readme.html or at
http://www.analog.cx/docs/Readme.html
