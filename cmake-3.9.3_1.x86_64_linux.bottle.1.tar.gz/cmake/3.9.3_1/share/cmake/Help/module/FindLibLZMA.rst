.. cmake-module:: ../../Modules/FindLibLZMA.cmake
