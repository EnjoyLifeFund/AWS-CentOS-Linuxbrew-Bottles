package explicit

import (
	"implicit"
)

func E() int {
	return implicit.I()
}
