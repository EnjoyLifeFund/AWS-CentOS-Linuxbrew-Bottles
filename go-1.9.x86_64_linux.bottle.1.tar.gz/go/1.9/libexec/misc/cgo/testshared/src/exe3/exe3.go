package main

import "dep3"

func main() {
	dep3.D3()
}
