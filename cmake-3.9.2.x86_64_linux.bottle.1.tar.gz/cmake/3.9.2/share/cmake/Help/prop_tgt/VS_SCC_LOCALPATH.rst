VS_SCC_LOCALPATH
----------------

Visual Studio Source Code Control Local Path.

Can be set to change the visual studio source code control local path
property.
