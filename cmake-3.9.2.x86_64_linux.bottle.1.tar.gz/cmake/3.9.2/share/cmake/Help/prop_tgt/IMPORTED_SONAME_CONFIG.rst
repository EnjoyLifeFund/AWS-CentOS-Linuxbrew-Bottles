IMPORTED_SONAME_<CONFIG>
------------------------

<CONFIG>-specific version of IMPORTED_SONAME property.

Configuration names correspond to those provided by the project from
which the target is imported.
