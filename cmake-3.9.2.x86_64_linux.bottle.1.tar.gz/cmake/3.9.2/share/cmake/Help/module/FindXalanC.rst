.. cmake-module:: ../../Modules/FindXalanC.cmake
